<template>
  <div class="about">
    <div class="container">
    <h4 class="center-align indigo-text text-darken-2">Nossa missão </h4><br>
        <p>Nossa paixão é projetar sistemas como serviços. Mas o que é um SaaS?</p>
        <p>SaaS, ou Software as a Service, é uma forma de disponibilizar softwares e soluções de tecnologia por meio da internet, como um serviço. Com esse modelo, sua empresa não precisa instalar, manter e atualizar hardwares ou softwares.
           O acesso é fácil e simples: apenas é necessária a conexão com a internet. </p>
        <p>Os aplicativos SaaS também são chamados de softwares baseados na Web, softwares sob demanda ou softwares hospedados. 
          Independente do nome, eles são executados nos servidores das empresas provedoras, que têm a responsabilidade de gerenciar o acesso e manter a estrutura de segurança de dados, conectividade e servidores necessários para o serviço.</p>
           <p>O SaaS vêm ganhando mais força a cada dia, devido aos muitos benefícios e às oportunidades oferecidas por esse modelo aos negócios de todos os portes e âmbitos.</p>
           <br> <br>
           <h4 class="center-align indigo-text text-darken-2">Nosso time</h4><br>
           <div class="row">
            <div class="col s6">
              <div class="card">
                <div class="card-image">
                  <img src="images/img4.jpg" alt="">
                  <button type="button" class="halfway-fab btn-floating indigo darken-2 ">
                    <i class="material-icons">account_circle</i>
                  </button>
                </div>
                <div class="card-content">
                  <span class="card-title">Raphael Aquini</span>
                  <p>Raphael é engenheiro de Controle e Automação pela UFMG. Tem experiência nacional e internacional em desenvolvimento de sistemas 
                    tendo trabalhado em diversas empresas do setor.
                    </p>
                </div>
                <div class="card-action indigo darken-2">
                  <a class="white-text" href="mailto:raquini@gmail.com">Email</a>
                  <a class="white-text" href="https://www.linkedin.com/in/raphael-aquini/">Linkedin</a>
                </div>
              </div>
            </div>
            <div class="col s6">
              <div class="card">
                <div class="card-image">
                  <img src="images/img4.jpg" alt="">
                  <button type="button" class="halfway-fab btn-floating indigo darken-2 ">
                    <i class="material-icons">account_circle</i>
                  </button>
                </div>
                <div class="card-content">
                  <span class="card-title">Marco Ferreira</span>
                  <p>
                    Marco é analista de sistemas pela UFMG. Tem experiência nacional e internacional em desenvolvimento de sistemas 
                    tendo trabalhado em diversas empresas do setor.
                  </p><br>
                </div>
                <div class="card-action indigo darken-2">
                  <a class="white-text" href="mailto:marco.mtfc@gmail.com">Email</a>
                  <a class="white-text" href="https://www.linkedin.com/in/marco-t%C3%BAlio-ferreira-ab162a31/">Linkedin</a>
                </div>
              </div>
            </div>
          </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'About',
  data(){

  }
}
</script>