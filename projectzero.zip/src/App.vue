<template>
  <div>
    <el-form>
      <el-input
        placeholder="Enter your name here"
        v-model="name"
      ></el-input>
      <el-input
        placeholder="Enter your job here"
        v-model="job"
      ></el-input>
      <br><br>
      <el-popover
      placement="right"
      title="New Employee added succesfully"
      width="1000"
      trigger="click"
    >
      <el-button round slot="reference" type="success" @click="createEmployee(name, date, job)"
        >Add New Employee</el-button
      >
       </el-popover>
    </el-form>
    
    <el-table
      :data="
        employeesData.filter(
          (data) =>
            !search || data.name.toLowerCase().includes(search.toLowerCase())
        )
      "
      style="width: 100%;"
    >
      <el-table-column label="Date" prop="date"> </el-table-column>
      <el-table-column label="Name" prop="name"> </el-table-column>
      <el-table-column label="Profession" prop="job"> </el-table-column>
      <el-table-column align="right">
        <template slot-scope="scope">
          <el-popover
            placement="bottom"
            title="Edit Employee"
            width="200"
            trigger="click"
          >
            <el-input
              placeholder="new name"
              v-model="scope.row.name"
            ></el-input>
            <el-input
              placeholder="new job"
              v-model="scope.row.job"
              @blur="updateEmployee(scope.row.id, scope.row.name, date, scope.row.job)"
            ></el-input>
            <el-button size="mini" slot="reference">Edit</el-button>
          </el-popover>
          <el-button
            size="mini"
            type="danger"
            @click="deleteEmployee(scope.row.id)"
            >Delete</el-button
          >
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import firebase from "./firebaseConfig";
const db = firebase.firestore();
export default {
  data() {
    return {
      name: "",
      job: "",
      date: new Date().toISOString().slice(0, 10),
      employeesData: [],
    };
  },
  methods: {
    createEmployee(name, date, job) {
      if (name != "") {
        db.collection("employees")
          .add({ date: date, name: name, job: job })
          .then(() => {
            console.log("Document successfully written!");
            this.readEmployees();
          })
        this.name = "";
        this.job = "";
      }
    },
    readEmployees() {
      this.employeesData = [];
      db.collection("employees")
        .get()
        .then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
            this.employeesData.push({
              id: doc.id,
              name: doc.data().name,
              date: doc.data().date,
              job: doc.data().job,
            });
            console.log(doc.id, " => ", doc.data());
          });
        })
    },
    updateEmployee(id, name, date, job) {
      db.collection("employees")
        .doc(id)
        .update({
          name: name,
          date: date,
          job: job,
        })
        .then(() => {
          console.log("Document successfully updated!");
          this.readEmployees();
        })
    },
    deleteEmployee(id) {
      db.collection("employees")
        .doc(id)
        .delete()
        .then(() => {
          console.log("Document successfully deleted!");
          this.readEmployees();
        })
    },
  },
  mounted() {
    this.readEmployees();
  },
};
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
